import tkinter.messagebox
from tkinter import *

play=Tk()
play.geometry('500x560')
play.title('Tic-Tac-Toc(Game Application)')
play.configure(bg='lightgreen')

def reset():
    global bclick, turns, playerA, playerB
    playerA = ''
    playerB = ''
    p1.set('')
    p2.set('')
    button1['text'] = ' '
    button2['text'] = ' '
    button3['text'] = ' '
    button4['text'] = ' '
    button5['text'] = ' '
    button6['text'] = ' '
    button7['text'] = ' '
    button8['text'] = ' '
    button9['text'] = ' '
def close():
    play.destroy()

playerA=StringVar()
playerB=StringVar()
p1=StringVar()
p2=StringVar()
bclick=True
turns=0
buttons=StringVar()

def btnclick(buttons):
    global playerA, playerB, bclick, turns
    if buttons['text'] == ' ' and bclick == True:
        buttons['text'] ='X'
        bclick=False
        playerA = p1.get()+ ' Wins!...'
        playerB = p2.get()+ ' Wins!...'
        possibilities()
        turns+=1
    elif buttons['text'] == ' ' and bclick == False:
        buttons['text'] = 'O'
        bclick= True
        possibilities()
        turns += 1
    else:
        tkinter.messagebox.showinfo('Tic-Tac-Toe','Button already clicked!....')
def  possibilities():
    if(button1['text'] =='X' and button2['text']=='X'and button3['text']=='X' or
         button4['text'] == 'X' and button5['text'] == 'X' and button6['text'] == 'X' or
         button7['text'] == 'X' and button8['text'] == 'X' and button9['text'] == 'X' or
         button1['text'] == 'X' and button4['text'] == 'X' and button7['text'] == 'X' or
         button2['text'] == 'X' and button5['text'] == 'X' and button8['text'] == 'X' or
         button3['text'] == 'X' and button6['text'] == 'X' and button9['text'] == 'X' or
         button1['text'] == 'X' and button5['text'] == 'X' and button9['text'] == 'X' or
         button3['text'] == 'X' and button5['text'] == 'X' and button7['text'] == 'X'):
        tkinter.messagebox.showinfo('Tic-Tac',playerA)
    elif(button1['text'] =='X' and button2['text']=='X'and button3['text']=='X' or
             button4['text'] == 'X' and button5['text'] == 'X' and button6['text'] == 'X' or
             button7['text'] == 'X' and button8['text'] == 'X' and button9['text'] == 'X' or
             button1['text'] == 'X' and button4['text'] == 'X' and button7['text'] == 'X' or
             button2['text'] == 'X' and button5['text'] == 'X' and button8['text'] == 'X' or
             button3['text'] == 'X' and button6['text'] == 'X' and button9['text'] == 'X' or
             button1['text'] == 'X' and button5['text'] == 'X' and button9['text'] == 'X' or
             button3['text'] == 'X' and button5['text'] == 'X' and button7['text'] == 'X'):
        tkinter.messagebox.showinfo('Tic-Tac',playerB)
    elif turns == 8:
        tkinter.messagebox.showinfo('Tic-Tac','Match Draw')

Label(play,text='Tic-Tac-Toe',font=('calibri',25),fg='green').place(x=170,y=10)

Label(play,text='Player A Name',font=('calibri',15),bg='lightgreen').place(x=90,y=70)
Label(play,text='Player B Name',font=('calibri',15),bg='lightgreen').place(x=90,y=100)

Entry(play,textvariable=p1, font=('calibri',13)).place(x=240,y=70)
Entry(play,textvariable=p2, font=('calibri',13)).place(x=240,y=100)

button1=Button(play,text=' ',command=lambda :btnclick(button1),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button1.place(x=100,y=170)

button2=Button(play,text=' ',command=lambda :btnclick(button2),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button2.place(x=215,y=170)

button3=Button(play,text=' ',command=lambda :btnclick(button3),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button3.place(x=330,y=170)

button4=Button(play,text=' ',command=lambda :btnclick(button4),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button4.place(x=100,y=270)

button5=Button(play,text=' ',command=lambda :btnclick(button5),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button5.place(x=215,y=270)

button6=Button(play,text=' ',command=lambda :btnclick(button6),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button6.place(x=330,y=270)

button7=Button(play,text=' ',command=lambda :btnclick(button7),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button7.place(x=100,y=370)

button8=Button(play,text=' ',command=lambda :btnclick(button8),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button8.place(x=215,y=370)

button9=Button(play,text=' ',command=lambda :btnclick(button9),font=('calibri',20,'bold'),bg='gray',fg='white',width=7,height=2)
button9.place(x=330,y=370)

Reset=Button(play, text='Reset',font=('calibri',15),bg='green',fg='white',width='7',height='1',command=reset)
Reset.place(x=180,y=480)

Close=Button(play, text='Close',font=('calibri',15),bg='green',fg='white',width='7',height='1',command=close)
Close.place(x=280,y=480)


play.mainloop()
